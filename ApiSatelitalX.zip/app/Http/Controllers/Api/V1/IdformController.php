<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Idform;
use Illuminate\Http\Request;

class IdformController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Idform $idform)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Idform $idform)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Idform $idform)
    {
        //
    }
}
