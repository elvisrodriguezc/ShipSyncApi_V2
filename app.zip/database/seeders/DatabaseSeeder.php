<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        \App\Models\Company::factory(2)->create();
        \App\Models\User::factory(5)->create();
        \App\Models\Unity::factory(5)->create();
        \App\Models\Brand::factory(5)->create();
        \App\Models\Currency::factory(3)->create();
        \App\Models\Ubigeodepartamento::factory(20)->create();
        \App\Models\Ubigeoprovincia::factory(50)->create();
        \App\Models\Ubigeodistrito::factory(120)->create();
        \App\Models\Office::factory(10)->create();
        \App\Models\Warehouse::factory(10)->create();
        \App\Models\Category::factory(8)->create();
        \App\Models\Product::factory(35)->create();
        \App\Models\Tariff::factory(3)->create();
        \App\Models\Tariffitem::factory(50)->create();
        \App\Models\Table::factory(20)->create();
        \App\Models\Cashier::factory(2)->create();
        \App\Models\Idform::factory(3)->create();
        \App\Models\Entity::factory(4)->create();
        \App\Models\Receipttype::factory(4)->create();
        \App\Models\Order::factory(2)->create();
        \App\Models\Orderitem::factory(10)->create();
        \App\Models\Purchase::factory(4)->create();
        \App\Models\Purchaseitem::factory(12)->create();

        \App\Models\User::factory()->create([
            'name' => 'Elvis Rodríguez',
            'email' => 'elvisrodriguezc@gmail.com',
            'password' => Hash::make('password')
        ]);
    }
}
