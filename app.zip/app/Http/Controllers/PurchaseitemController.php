<?php

namespace App\Http\Controllers;

use App\Models\Purchaseitem;
use App\Http\Requests\StorePurchaseitemRequest;
use App\Http\Requests\UpdatePurchaseitemRequest;

class PurchaseitemController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorePurchaseitemRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Purchaseitem $purchaseitem)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatePurchaseitemRequest $request, Purchaseitem $purchaseitem)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Purchaseitem $purchaseitem)
    {
        //
    }
}
