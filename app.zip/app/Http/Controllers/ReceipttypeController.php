<?php

namespace App\Http\Controllers;

use App\Models\Receipttype;
use App\Http\Requests\StoreReceipttypeRequest;
use App\Http\Requests\UpdateReceipttypeRequest;

class ReceipttypeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreReceipttypeRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Receipttype $receipttype)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateReceipttypeRequest $request, Receipttype $receipttype)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Receipttype $receipttype)
    {
        //
    }
}
