<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class OrderResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        switch ($this->status) {
            case 0:
                $statVal = 'Anulado';
                break;
            case 1:
                $statVal = 'Activo';
                break;
            case 2:
                $statVal = 'En Producción';
                break;

            default:
                $statVal = 'No especificado';
                break;
        }
        return [
            'id' => (int)$this->id,
            'company_id' => $this->company_id,
            'company' => [
                'id' => $this->company->id,
                'name' => $this->company->name,
                'ruc' => $this->company->ruc,
                'address' => $this->company->address,
                'phone' => $this->company->phone,
                'email' => $this->company->email,
                'logo' => $this->company->logo,
                'web' => $this->company->web,
                'description' => $this->company->description,
            ],
            'cashier_id' => $this->cashier_id,
            'cashier' => [
                'id' => $this->cashier->id,
                'status' => $this->cashier->status,
                'created_at' => $this->cashier->created_at->format('Y-m-d H:i:s'),
            ],
            // 'cashier'=>new CashierResource( $this->cashier),
            'user_id' => $this->user_id,
            'user' => [
                'id' => $this->user->id,
                'name' => $this->user->name,
            ],
            // 'user'=>new UserResource( $this->user),
            'entity_id' => $this->entity_id,
            'entity' => [
                'id' => $this->entity->id,
                'first_name' => $this->entity->first_name,
                'last_name' => $this->entity->last_name,
                'id_form_number' => $this->entity->id_form_number,
                'address' => $this->entity->address,
                'phone' => $this->entity->phone,
            ],
            // 'customer'=>new CustomerResource( $this->customer),
            'table_id' => $this->table_id,
            'table' => [
                'id' => $this->table->id,
                'name' => $this->table->name,
                'seatcount' => $this->table->seatcount,
                'status' => $this->table->status,
            ],
            // 'table'=>new TableResource( $this->table),
            'items' => new OrderitemCollection($this->orderitem),
            // 'receipts' => new ReceiptCollection($this->receipt),
            'tariff_id' => $this->tariff_id,
            'tariff' => [
                'id' => $this->tariff->id,
                'name' => $this->tariff->name,
                // 'company_id' => $this->tariff->company_id,
                'rate' => $this->tariff->rate,
            ],
            // 'tariff'=>new TariffResource( $this->tariff),
            'number' => $this->number,
            'pax' => $this->pax,
            'discount_percent' => $this->discount_percent,
            'total' => (float)$this->total,
            'currency_id' => $this->currency_id,
            'currency' => $this->currency->symbol,
            'status' => $statVal,
            'created_at1' => $this->created_at->format('Y-m-d H:i:s'),
            'updated_at1' => $this->updated_at->format('Y-m-d H:i:s'),
        ];
    }
}
