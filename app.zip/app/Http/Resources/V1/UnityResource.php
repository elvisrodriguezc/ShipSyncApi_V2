<?php

namespace App\Http\Resources\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class UnityResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        $statusLabel = '';
        switch ($this->status) {
            case 0:
                $statusLabel = 'anulado';
                break;
            case 1:
                $statusLabel = 'activo';
                break;
            case 2:
                $statusLabel = 'en proceso';
                break;
            case 3:
                $statusLabel = 'suspendido';
                break;
            default:
                $statusLabel = 'unknown';
                break;
        }

        return [
            'id' => $this->id,
            'name' => $this->name,
            'abbreviation' => $this->abbreviation,
            'value' => $this->value,
            'status' => $statusLabel,
            // 'created_at' => $this->created_at->format('Y-m-d H:i:s'),
            // 'updated_at' => $this->updated_at->format('Y-m-d H:i:s')
        ];
    }
}
